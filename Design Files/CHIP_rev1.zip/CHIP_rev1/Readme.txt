File list:

CHIP_rev1.GBL	Bottom Layer
CHIP_rev1.GBS	Bottom Solder Mask
CHIP_rev1.GM1	Board outline
CHIP_rev1.GTL	Top Layer
CHIP_rev1.GTO	Top Overlay Silk Screen
CHIP_rev1.GTS	Top Solder Mask
CHIP_rev1.TXT	Drill file
